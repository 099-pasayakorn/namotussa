import express from 'express'
import officeRouter from './routes/office-route.js'
import productLineRouter from "./routes/productline-route.js";
import productRouter from "./routes/product-route.js";
import brandRouter from "./routes/brand-route.js";
import {errorHandler} from "./middlewares/error-handler.js";
import {queryParser} from "./middlewares/pagination-middleware.js";

const ID = '6852000A'
const app = express()
app.use(express.json())
app.use(queryParser())
// Test queryParser
app.get('/', (req, res) => {
    console.log(req.pagination)
    res.json(req.pagination)
})
const STUDENT_ID = '68130500099'
app.get(`/api/${STUDENT_ID}/student-info`, (req, res) => {
    res.status(200).json({
        success: true,
        data: {
            studentId: "68130500099",
            name: "Pasayakorn Pansint",
            secretKey: "67KaSu"
        },
        timestamp: "2026-10-08T15:00:00.000Z"
    })
})
app.use(`/api/${STUDENT_ID}/brands`, brandRouter)
app.use(`/api/${ID}/offices`, officeRouter)
app.use(`/api/${ID}/productlines`, productLineRouter)
app.use(`/api/${STUDENT_ID}/products`, productRouter)

app.listen(3000, () => {
    console.log('Example app listening on port 3000')
})

app.use(errorHandler)